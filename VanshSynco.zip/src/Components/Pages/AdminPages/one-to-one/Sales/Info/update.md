  (Work Done Synco)

  1. One to One & Birthday Party Booking
      ______________________________________

     . Postal Code Field Update
     . Medical Information and How did you hear about us is visible after the booking
       When I tries to check the details in Sales tab.
     . Update One to one See details Data Fix Refresh Issue
     . Update Routing in One to One session plan 
     . Fix Session plan structure UI Issue
     . Fix Filters Issues In Sales or all Tab in 
     . Add Loading when filter data or load data  add msgs when data lenght 0
     . Date Format Change in Payment History Tab
     . Add Comments Section in Student Profile
     . Apply Send Email
     . Fix Student Add ISSUE
     . fix parent profile add or input change issue's
     . date of Booking is wrong in Service History in One to One
     . Change Package Interest Field Into Select options
     . Venue is not visible outside of the profile in sales tab
     . Added Swal Messages for date filter

   2. Waiting List
      ____________

     . Comments are static in parent profile
     . Fix Student Profile Issue






(Work Done Goldquest )

 1. (Admin & Customer Login)

 . Add Password Filled Acc to Additonal Required
 . Prefill Password in Edit Form
 . Apply Login Submision acc to Additional Login  (Add Selec Dropdown) 
 . Send Additional user Id Acc to Type Addition in all API CALL in Customer Login







     



