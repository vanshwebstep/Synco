import workerSrc from "pdfjs-dist/build/pdf.worker.min.mjs?url";
export default workerSrc;
