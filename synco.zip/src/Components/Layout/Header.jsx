import React from 'react';
import { Search, Bell, ChevronUp, ChevronDown } from 'lucide-react';
import profileLogo from '../../assets/images/demoprofile.png';
import Welcomeback from '../../assets/images/Welcomeback.png'

const Header = ({ profileOpen, setProfileOpen }) => {
  return (
    <header className="flex justify-between items-center py-6 px-8 bg-gray-50 border-b">
      <div>
        <span className=" font-semibold text-[26px]">Hi Nillo !</span>
        <h2 className="text-[36px] font-semibold flex gap-2 items-center whitespace-nowrap "> Welcome Back<img src={Welcomeback} alt="" className='w-10 h-10' /> </h2>
      </div>
      <div className="flex items-center  gap-6">
<div className="searchbar relative w-[250px] md:w-[280px] lg:w-[200px] xl:w-[250px] 2xl:w-[400px]">          <input
            type="search"
            className="w-full px-4 py-3 pl-8 border border-[#E2E1E5] rounded-lg bg-white text-base focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Search"
          />
          <Search className="absolute right-3 top-1/2 left-2 transform -translate-y-1/2 text-black" size={20} />
        </div>
        <div className="circle w-12 h-12 bg-white border  border-[#E2E1E5]  rounded-full flex items-center justify-center text-black ">
          <Bell size={20} />
        </div>
        <div className="flex  items-center text-right pr-10">
          <div className="datemonth text-sm text-gray-600 border-r border-gray-300 pr-4 mr-4">
            <span className="block text-base  text-gray-800 font-semibold ">January</span>
            <span className='font-semibold text-gray-600'>8 Monday 2024</span> 
          </div>
          <div className="relative">
            <div
              className="profile mt-2 flex items-center gap-3 cursor-pointer"
              onClick={() => setProfileOpen(!profileOpen)}
            >
              <div className="profileimg w-10 h-10 bg-gray-300 rounded-full">
                <img src={profileLogo} alt="" />
              </div>
              <div className="block gap-1 text-start ">
                <div className='flex items-center gap-1 '>
                <span className="text-base font-semibold  leading-[1px]">Nilo V Bagga</span>
                 {profileOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
             <span className="text-sm text-gray-600 font-semibold ">Super Admin</span>  
              </div>
            </div>
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white shadow-lg rounded-md border z-10">
                <ul className="text-sm text-gray-700 divide-y divide-gray-100">
                  <li className="px-4 py-2 hover:bg-gray-50 cursor-pointer">My Profile</li>
                  <li className="px-4 py-2 hover:bg-gray-50 cursor-pointer">Settings</li>
                  <li className="px-4 py-2 hover:bg-gray-50 cursor-pointer">Logout</li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
