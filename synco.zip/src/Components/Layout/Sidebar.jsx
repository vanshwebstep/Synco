import React, { useState } from 'react';
import {
    LayoutGrid, Package, Truck, User, ChevronDown,ChevronUp, ChevronRight, MessageCircle, FileText, Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import Dashboard from '../../assets/SidebarLogos/Dashboard.png'
import DashboardH from '../../assets/SidebarLogos/DashboardH.png'

import WeeklyClasses from '../../assets/SidebarLogos/WeeklyClasses.png'
import WeeklyClassesH from '../../assets/SidebarLogos/WeeklyClassesH.png'

import OneTOOne from '../../assets/SidebarLogos/OneTOOne.png'
import OneTOOneH from '../../assets/SidebarLogos/OneTOOneH.png'

import Holiday from '../../assets/SidebarLogos/Holiday.png'
import HolidayH from '../../assets/SidebarLogos/HolidayH.png'

import Birthday from '../../assets/SidebarLogos/Birthday.png'
import BirthdayH from '../../assets/SidebarLogos/BirthdayH.png'

import Club from '../../assets/SidebarLogos/Club.png'
import ClubH from '../../assets/SidebarLogos/ClubH.png'

import Merchandise from '../../assets/SidebarLogos/Merchandise.png'
import MerchandiseH from '../../assets/SidebarLogos/MerchandiseH.png'

import Management from '../../assets/SidebarLogos/Management.png'
import ManagementH from '../../assets/SidebarLogos/ManagementH.png'

import Survey from '../../assets/SidebarLogos/Survey.png'
import SurveyH from '../../assets/SidebarLogos/SurveyH.png'

import Marketing from '../../assets/SidebarLogos/Marketing.png'
import MarketingH from '../../assets/SidebarLogos/MarketingH.png'

import Recruitment from '../../assets/SidebarLogos/Recruitment.png'
import RecruitmentH from '../../assets/SidebarLogos/RecruitmentH.png'

import Reports from '../../assets/SidebarLogos/Reports.png'
import ReportsH from '../../assets/SidebarLogos/ReportsH.png'

import MarketingReports from '../../assets/SidebarLogos/MarketingReports.png'
import MarketingReportsH from '../../assets/SidebarLogos/MarketingReportsH.png'

import ReqReports from '../../assets/SidebarLogos/ReqReports.png'
import ReqReportsH from '../../assets/SidebarLogos/ReqReportsH.png'

import SyncoChat from '../../assets/SidebarLogos/bubble-chat.png'
import SyncoChatH from '../../assets/SidebarLogos/bubble-chatH.png'

import Template from '../../assets/SidebarLogos/Template.png'
import TemplateH from '../../assets/SidebarLogos/TemplateH.png'

import Administration from '../../assets/SidebarLogos/Admistration.png'
import AdministrationH from '../../assets/SidebarLogos/AdmistrationH.png'
import Syncologo from '../../assets/images/synco-text.png';
const menuItems = [
    { title: 'Dashboard', icon: Dashboard, iconHover: DashboardH, link: '#' },
    { title: 'Weekly Classes', icon: WeeklyClasses, iconHover: WeeklyClassesH, subItems: ['Camp 1', 'Camp 2'] },
    {
        title: 'One to One', icon: OneTOOne, iconHover: OneTOOneH, 
    },
    { title: 'Holiday Camps', icon: Holiday, iconHover: HolidayH, subItems: ['Camp 1', 'Camp 2'] },
    { title: 'Birthday parties', icon: Birthday, iconHover: BirthdayH, subItems: ['Party 1', 'Party 2'] },
    { title: 'Club', icon: Club, iconHover: ClubH, subItems: [
            { title: 'Session A', innerSubItems: ['Slot 1', 'Slot 2'] },
            { title: 'Session B', innerSubItems: ['Slot 3', 'Slot 4'] },
            { title: 'Session C' }
        ]},
    { title: 'Merchandise', icon: Merchandise, iconHover: MerchandiseH, link: '#' },
    { title: 'Email management', icon: Management, iconHover: ManagementH, link: '#' },
    { title: 'Surveys', icon: Survey, iconHover: SurveyH, subItems: ['Survey 1', 'Survey 2'] },
    { title: 'Email marketing', icon: Marketing, iconHover: MarketingH, subItems: ['Campaign 1', 'Campaign 2'] },
    { title: 'Recruitment', icon: Recruitment, iconHover: RecruitmentH, subItems: ['Job 1', 'Job 2'] },
    { title: 'Reports', icon: Reports, iconHover: ReportsH, subItems: ['Report 1', 'Report 2'] },
    { title: 'Marketing reports', icon: MarketingReports, iconHover: MarketingReportsH, subItems: ['Report A', 'Report B'] },
    { title: 'Recruitment reports', icon: ReqReports, iconHover: ReqReportsH, link: '#' },
    { title: 'Synco Chat', icon: SyncoChat, iconHover: SyncoChatH, link: '#' },
    { title: 'Templates', icon: Template, iconHover: TemplateH, link: '#' },
    { title: 'Administration', icon: Administration, iconHover: AdministrationH, link: '#' },
];

const Sidebar = () => {
    const [openDropdowns, setOpenDropdowns] = useState({});
    const [hoveredItem, setHoveredItem] = useState(null);

    const toggleDropdown = (title) => {
        setOpenDropdowns((prev) => ({ ...prev, [title]: !prev[title] }));
    };

    const renderMenuItems = (items, level = 0) => (
        <ul className={`${level === 0 ? 'px-4' : 'pl-10'} ${level === 2 ? 'list-disc' : 'list-none'} space-y-1`}>
            {items.map((item) => {
                const hasSubItems = Array.isArray(item.subItems);
                const hasInnerSubItems = Array.isArray(item.innerSubItems);
                const itemTitle = typeof item === 'string' ? item : item.title;

                return (
                    <li className="mb-2 text-lg " key={itemTitle}>
                        <motion.div
                            initial={false}
                            onClick={() => (hasSubItems || hasInnerSubItems) && toggleDropdown(itemTitle)}
                            onMouseEnter={() => setHoveredItem(itemTitle)}
                            onMouseLeave={() => setHoveredItem(null)}
                            className={`
                                flex items-center justify-between font-semibold  cursor-pointer px-4 py-2 rounded-lg 
                                transition-all duration-100
                                ${level === 0
                                    ? 'bg-gradient-to-r from-transparent to-transparent hover-bg-blue-color font-semibold hover:sfont-normal hover:text-white text-black'
                                    : 'hover:text-blue-600'
                                }`}
                        >
                            <span className="flex items-center  gap-3 transition-all duration-100">
                                {item.icon && level === 0 && (
                                    <motion.img
                                        src={hoveredItem === itemTitle ? item.iconHover : item.icon}
                                        alt={itemTitle}
                                        className="w-6 h-6 transition duration-100 ease-in-out"
                                        initial={{ opacity: 0.8 }}
                                        animate={{ opacity: 1 }}
                                    />
                                )}
                                <span className="transition-all duration-100">{itemTitle}</span>
                            </span>
                            {level === 0 && hasSubItems && (
                                openDropdowns[itemTitle] ? <ChevronUp size={20} /> : <ChevronDown size={20} />
                            )}
                            {level === 1 && hasInnerSubItems && <span className="ml-2 text-sm">-</span>}
                        </motion.div>

                        <AnimatePresence initial={false}>
                            {(hasSubItems || hasInnerSubItems) && openDropdowns[itemTitle] && (
                                <motion.div
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: "auto", opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ duration: 0.3 }}
                                >
                                    {hasSubItems && renderMenuItems(item.subItems, level + 1)}
                                    {hasInnerSubItems && renderMenuItems(item.innerSubItems, level + 1)}
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </li>
                );
            })}
        </ul>
    );

    return (
        <aside className="w-72 h-screen bg-white border-r flex flex-col shadow-lg">
            <div className="p-6 font-semibold text-2xl text-center flex items-center justify-center">
                <img src={Syncologo} alt="Logo" className="h-10 w-auto object-contain" />
            </div>
            <nav className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-500">
                {renderMenuItems(menuItems)}
            </nav>
        </aside>
    );
};

export default Sidebar;
