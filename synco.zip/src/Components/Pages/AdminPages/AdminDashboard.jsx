import React from 'react'
import { useState } from 'react';
import { Search, Bell, ChevronUp } from 'lucide-react';
import profileLogo from '../../../assets/images/demoprofile.png'
import { CalendarDays, Users, ShoppingCart, LineChart, Star, AlertCircle, BarChart, Smile, Briefcase, Calendar, Plus } from "lucide-react";
import welcomeToDashboard from '../../../assets/images/welcomeToDashboard.png'
import ArrowFall from '../../../assets/images/ArrowFall.png'
import Arrowtop from '../../../assets/images/Arrowtop.png'
import { Eye, EyeOff } from 'lucide-react';
import { Circle, MoreHorizontal } from 'lucide-react';
import { Sliders } from 'lucide-react';
import { ChevronLeft, ChevronRight } from "lucide-react";
import { AlertOctagon } from 'lucide-react';
import CalendarImg from '../../../assets/DashboardIcons/calendar-03.png';
import Cancel from '../../../assets/DashboardIcons/cancel-02.png';
import Chart from '../../../assets/DashboardIcons/chart.png';
import customersupport from '../../../assets/DashboardIcons/customer-support.png';
import shoppingcart from '../../../assets/DashboardIcons/shopping-cart.png';
import dollarcircle from '../../../assets/DashboardIcons/dollar-circle.png';
import usergroup from '../../../assets/DashboardIcons/user-group.png';
import useradd01 from '../../../assets/DashboardIcons/user-add--01.png';
import greendot from '../../../assets/DashboardIcons/greendot.png';
import orangedot from '../../../assets/DashboardIcons/orangedot.png';



const AdminDashboard = () => {
const metrics = [
  { icon: <img src={usergroup} alt="Total Students" className="w-6 h-6" />, title: "Total Students", value: 2504, bg: "bg-gray-100" },
  { icon: <img src={CalendarImg} alt="Trials Booked" className="w-6 h-6" />, title: "Trials Booked", value: 1892, bg: "bg-pink-100" },
  { icon: <img src={Cancel} alt="Cancellations" className="w-6 h-6" />, title: "Cancellations", value: 453, bg: "bg-red-100", showIcons: true },
  { icon: <img src={dollarcircle} alt="Revenue" className="w-6 h-6" />, title: "Revenue", value: "£98,283", bg: "bg-rose-100" },
  { icon: <img src={Chart} alt="Capacity" className="w-6 h-6" />, title: "Capacity", value: 345, bg: "bg-yellow-100" },
  { icon: <img src={useradd01} alt="Growth" className="w-6 h-6" />, title: "Growth", value: 343, bg: "bg-orange-100", showIcons: true },
  { icon: <img src={customersupport} alt="Customer Satisfaction" className="w-6 h-6" />, title: "Customer Satisfaction", value: 4.3, bg: "bg-green-100" },
  { icon: <img src={shoppingcart} alt="Merchandise Sales" className="w-6 h-6" />, title: "Merchandise Sales", value: "£37,812", bg: "bg-cyan-100" },
];


  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth(); // 0-indexed
  const today = new Date();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const daysInMonth = lastDayOfMonth.getDate();
  const startDay = firstDayOfMonth.getDay(); // Sunday = 0

  // Build calendar array with empty slots at the beginning
  const calendarDays = [
    ...Array(startDay).fill(null),
    ...Array(daysInMonth).fill().map((_, i) => i + 1),
  ];

  const goToPreviousMonth = () => {
    const prevMonth = new Date(year, month - 1, 1);
    setCurrentDate(prevMonth);
  };

  const goToNextMonth = () => {
    const nextMonth = new Date(year, month + 1, 1);
    setCurrentDate(nextMonth);
  };


  return (
    <>
      <div className="bg-gray-100 min-h-screen p-6 font-sans">

        <div className="flex flex-col lg:flex-row mt-6 gap-6">
          {/* Main Content */}
          <div className="w-full lg:w-9/12">
            {/* Welcome Banner */}
            <div
              className="bg-yellow-300 rounded-3xl p-6 py-18 pb-5 flex justify-between items-center text-white relative overflow-hidden"
              style={{
                backgroundImage: `url(${welcomeToDashboard})`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'left',
                backgroundSize: 'contain',
              }}
            >
              <div className="text-end w-full">
                <h2 className="text-[24px] font-semibold text-black z-10">Monday 3rd June 2025</h2>
                <h5 className="text-[28px] font-bold z-10 text-black">Welcome to your dashboard, Nilio</h5>
              </div>
              <div className="absolute inset-0 opacity-80 rounded-xl" />
            </div>

            {/* Scorecard Header */}
            <div className="flex justify-between items-center my-6 flex-wrap gap-2">
              <h2 className="text-[28px] font-semibold Gilroy">Weekly Classes Scorecards</h2>
              <button className="text-sm p-2 rounded-lg text-white font-semibold  bg-blue">
                Reorder Your Widgets
              </button>
            </div>

            {/* Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {metrics.map((metric, i) => (
                <div key={i} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className="flex mb-5 justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`text-3xl p-2 rounded-full ${metric.bg}`}>{metric.icon}</div>
                      <div>
                        <h3 className="text-[16px] text-gray-700">{metric.title}</h3>
                        <p className="text-[28px] font-semibold text-gray-900">{metric.value}</p>
                      </div>
                    </div>

                    {(metric.title === "Cancellations" || metric.title === "Growth") && (
                      <div className="flex justify-end gap-2 items-start">
                        <Eye className="w-7 h-7" />
                        <div className="relative w-3 h-3">
                          <Circle className="absolute" />
                          <MoreHorizontal className="absolute h-4 top-1" />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-start gap-5 items-end">
                    <div className="text-xs text-gray-400 mt-2 block">
                      <span className="font-semibold  text-black flex items-center gap-2"> <img src={orangedot} alt="" /> Last Month</span>
                      <br />
                      <span className="text-red-500  font-semibold bg-red-100 p-1 rounded-lg flex justify-center mt-2">
                        -0.56% <img src={ArrowFall} alt="" />
                      </span>
                    </div>
                    <div className="text-xs text-gray-400 block">
                      <span className="font-semibold text-black flex items-center gap-2"><img src={greendot} alt="" />  This Week</span>
                      <br />
                      <span className="text-green-500 font-semibold bg-gray-100 p-1 rounded-lg flex justify-center mt-2">
                        +5.27% <img src={Arrowtop} alt="" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h2 className="text-xl font-bold mt-8">Other Services Scorecards</h2>
          </div>

          {/* Sidebar */}
          <div className="w-full lg:w-3/12 space-y-6">
            {/* Filter Panel */}
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="font-semibold">Filter by date</h3>
                <button className="flex gap-2 items-center bg-blue-500 text-white p-2 rounded-lg text-sm">
                  <Sliders className="w-5 h-5" /> Apply filter
                </button>
              </div>

              <div className="gap-2 text-sm bg-gray-100 p-2 my-6 rounded">
                <label className="font-bold block mb-2">Choose type</label>
                <div className="flex flex-wrap gap-2">
                  {["This Year", "This Month", "This Week", "Last Year", "Last Month", "Last Week"].map((label, i) => (
                    <label key={i} className="flex items-center w-[45%] space-x-1">
                      <input type="checkbox" className="accent-blue-600" />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Calendar */}
              <div className="rounded p-4 text-center text-sm w-full">
                <div className="flex justify-around items-center mb-3">
                  <button
                    onClick={goToPreviousMonth}
                    className="w-8 h-8 rounded-full bg-white text-black hover:bg-black hover:text-white border border-black flex items-center justify-center"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <p className="font-semibold text-lg">
                    {currentDate.toLocaleString("default", { month: "long" })} {year}
                  </p>
                  <button
                    onClick={goToNextMonth}
                    className="w-8 h-8 rounded-full bg-white text-black hover:bg-black hover:text-white border border-black flex items-center justify-center"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>

                <div className="grid grid-cols-7 text-xs gap-1 text-gray-500 mb-1">
                  {["S", "M", "T", "W", "T", "F", "S"].map((day) => (
                    <div key={day} className="font-medium text-center">{day}</div>
                  ))}
                </div>

                <div className="grid grid-cols-7 text-xs gap-1">
                  {calendarDays.map((day, i) => (
                    <div
                      key={i}
                      className={`w-8 h-8 flex items-center justify-center rounded-full mx-auto ${day === today.getDate() &&
                        month === today.getMonth() &&
                        year === today.getFullYear()
                        ? "bg-blue-600 text-white"
                        : "text-gray-700"
                        }`}
                    >
                      {day || ""}
                    </div>
                  ))}
                </div>
              </div>

              <button className="bg-blue-600 mt-4 w-full text-white py-2 rounded text-sm">
                Apply Filter
              </button>
            </div>

            {/* Task List */}
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">My Tasks</h3>
                <button className="bg-blue-600 text-white px-2 py-1 rounded text-xs flex items-center space-x-1">
                  <Plus size={14} /> <span>Add New Task</span>
                </button>
              </div>
              <ul className="text-sm text-gray-600">
                {[
                  { label: "Meeting", date: "30 Nov 2021", alert: true },
                  { label: "Weekly meeting", date: "24 Nov 2022" },
                  { label: "Add new services", date: "24 Nov 2022" },
                ].map((task, i) => (
                  <li key={i} className="flex justify-between items-center border-t py-2">
                    <div className="flex items-center gap-2">
                      <p className="flex items-center gap-2">
                        {task.label}
                        {task.alert && (
                          <div className="w-4 h-4 bg-red-500 clip-hexagon flex items-center justify-center text-white font-bold text-xs shrink-0">
                            !
                          </div>
                        )}
                      </p>
                      <p className="text-xs text-gray-400">{task.date}</p>
                    </div>
                    <span className="text-xs bg-gray-100 p-1 rounded-lg font-bold">6:15 PM</span>
                  </li>
                ))}
              </ul>

              <button className="mt-2 text-xs text-blue-600 flex items-center">
                View All <ChevronRight className="w-5 h-5 text-blue-600" />
              </button>
            </div>
          </div>
        </div>

      </div>


    </>
  )
}
export default AdminDashboard