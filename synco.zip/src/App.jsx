import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import AdminLogin from './Components/AdminLogin.jsx';
import AdminDashboard from './Components/Pages/AdminPages/AdminDashboard.jsx';
import AdminLayout from './Components/Layout/AdminLayout.jsx';
import ProtectedRoute from './Components/ProtectedRoute.jsx';
import './App.css';

function AppRoutes() {
  const location = useLocation();
  const isAdminLogin = location.pathname === '/admin-login';

  if (isAdminLogin) {
    return (
      <div className='login-container'>
      <div className="login-container-inner">
        <Routes>
          <Route path="/admin-login" element={<AdminLogin />} />
        </Routes>
      </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route
        path="/"
        element={
          <AdminLayout>
             <ProtectedRoute>
            <AdminDashboard />
             </ProtectedRoute>
          </AdminLayout>
        }
      />
      {/* Add other routes similarly */}
    </Routes>
  );
}

function App() {
  return (
    <Router>
      <AppRoutes />
    </Router>
  );
}

export default App;
